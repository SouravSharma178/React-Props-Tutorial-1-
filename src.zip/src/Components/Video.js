import React from 'react'
import './Video.css'

const Video = ({srcValue,channel="Coder Dost",views,verified}) => {
    let status;
    if(verified){
      status = <div className='status'>Channel is verified ✅</div>
    } else{
        status = <div className='status'>Channel is Unverified</div>;
    }
  return(
    <>
   <div className='ChildContainerFlex'>
    <div className='Thumbnail'>
    <img src={srcValue} alt="" style={{height:170,width:250}}/>
    </div>
    <div className='channelName'>
    {channel}
    </div>
    <div className='Views'>
    {views}
    </div>
    <div className='Verified'>
     {status}
    </div>
   </div>
    </>
  )
}


export {Video}
