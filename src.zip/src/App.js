import React from 'react'
import './App.css';
import {Video} from './Components/Video'

const App = () => {
  let obj = {
    channel:"Coder Dost",
    views:"25K"
  }
  return(
  <div className='container'>
  <Video {...obj} srcValue="https://images.unsplash.com/photo-1716837894890-f9c456bbee99?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwxOXx8fGVufDB8fHx8fA%3D%3D" verified={false}></Video>
  <Video channel="Mr.Beast" views="110K" verified={true} srcValue="https://images.unsplash.com/photo-1715276611613-97056c19b775?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwxMHx8fGVufDB8fHx8fA%3D%3D"></Video>
  <Video views="1M" verified={1} srcValue="https://images.unsplash.com/photo-1715457710066-3bc88052dc0e?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw0fHx8ZW58MHx8fHx8"></Video>
  </div>
)
}
export default App;
